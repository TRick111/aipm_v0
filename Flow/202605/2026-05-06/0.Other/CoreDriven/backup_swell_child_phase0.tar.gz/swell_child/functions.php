<?php

/* 子テーマのfunctions.phpは、親テーマのfunctions.phpより先に読み込まれることに注意してください。 */

/**
 * 子テーマでのファイルの読み込み
 */

add_action('wp_enqueue_scripts', function () {

    // JavaScriptファイルのタイムスタンプ（キャッシュ回避用）
    $timestamp_js = date('Ymdgis', filemtime(get_stylesheet_directory() . '/main.js'));
    wp_enqueue_script('child_script', get_stylesheet_directory_uri() . '/main.js', [], $timestamp_js, true);

    /* その他の読み込みファイルはこの下に記述 */
}, 11);

add_post_type_support('page', 'page-attributes');

?>

<?php
// 子テーマのスタイルシートを読み込む関数を作成
function enqueue_child_theme_styles()
{
    // 親テーマのスタイルシートを読み込む
    wp_enqueue_style('parent-style', get_template_directory_uri() . '/style.css');

    // 子テーマの追加スタイルシートを読み込む
    wp_enqueue_style(
        'child-theme-style', // ハンドル名
        get_stylesheet_directory_uri() . '/assets/style.css', // ファイルのパス
        array('parent-style'), // 親テーマのスタイルに依存
        '1.0.0', // バージョン（キャッシュ回避のため）
        'all' // メディアタイプ
    );
}

// WordPressのフックに登録
add_action('wp_enqueue_scripts', 'enqueue_child_theme_styles');
?>

