document.addEventListener("DOMContentLoaded", function () {
    function wrapCustomBlocks() {
        const customBlocks = document.querySelectorAll(".custom_block:not(.wrapped)");
        customBlocks.forEach((block, index) => {
            // 最初のラッパーを作成
            const outerWrapper = document.createElement("div");
            outerWrapper.className = `custom-wrapper${String(index + 1).padStart(2, "0")}`;

            // 内側のラッパーを作成
            const innerWrapper = document.createElement("div");
            innerWrapper.className = `custom-block-wrapper${String(index + 1).padStart(2, "0")}`;

            // ラッパーの組み込み
            block.parentNode.insertBefore(outerWrapper, block);
            outerWrapper.appendChild(innerWrapper);
            innerWrapper.appendChild(block);

            // ラップ済みマークを追加
            block.classList.add("wrapped");
        });
    }

    wrapCustomBlocks();

    const observer = new MutationObserver(wrapCustomBlocks);
    observer.observe(document.body, { childList: true, subtree: true });
});

window.addEventListener('load', () => {
    const messageElement = document.querySelector('.message');
    messageElement.classList.add('show');
});



document.addEventListener('DOMContentLoaded', () => {
    const bg = document.querySelector('.custom-background');

    // IntersectionObserverの設定
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        root: null,
        threshold: 1
    });

    observer.observe(bg);
});

// --------------------------------------------------
// 以下、残す（修正後の）コードのみ
// --------------------------------------------------
document.addEventListener('DOMContentLoaded', function () {
    // 画面幅が768px以下なら「モバイル版」として扱う
    const isMobile = window.innerWidth <= 768;

    // モバイル版用の <h1> (改行を増やすなど)
    const mobileMessageHTML = `
    <h1 class="message">
      <span class="highlight">
        新たな<br>
        <span class="bigbtext">ビジネスモデルに</span><br>
        <span class="subtext">挑戦する</span>
      </span>
      <br />
      <span class="partner">事業共創パートナー</span>
    </h1>
  `;

    // PC版用の <h1> (従来のレイアウト)
    const pcMessageHTML = `
    <h1 class="message">
      <span class="highlight">
        新たな<span class="bigbtext">ビジネスモデルに</span>
        <span class="subtext">挑戦する</span>
      </span>
      <br />
      <span class="partner">事業共創パートナー</span>
    </h1>
  `;

    // モバイルかPCかで <h1> の中身を分岐
    const messageHTML = isMobile ? mobileMessageHTML : pcMessageHTML;

    // 新しい要素を作成
    const newElement = document.createElement('div');
    newElement.id = 'header';

    // innerHTML全体を設定（SVG部分を省略せず完全貼り付け）
    newElement.innerHTML = `
    <div class="logo_anime__container">
      <svg class="logo_anime__logo" viewBox="0 0 1085.085 339.397">

        <!-- Text core -->
        <g class="logo_anime__text">
          <!-- c -->
          <path
            class="logo_anime__text-path logo_anime__delay-800"
            d="M558.84,144.84c-12.336,4.893-23.751,7.338-34.243,7.338c-18.291,0-34.668-5.849-49.131-17.547
               c-18.434-14.958-27.649-34.455-27.649-58.489s9.215-43.636,27.649-58.596C490.929,5.848,507.412,0,525.916,0
               c10.066,0,21.375,2.446,33.924,7.338v45.196c-3.551-4.354-7.171-7.637-10.864-9.85c-6.746-4.068-13.987-6.102-21.726-6.102
               c-9.798,0-18.319,2.951-25.561,8.85c-9.159,7.464-13.738,17.702-13.738,30.71c0,12.939,4.579,23.14,13.738,30.604
               c7.241,5.9,15.762,8.85,25.561,8.85c7.738,0,14.979-2.034,21.726-6.102c3.621-2.14,7.242-5.424,10.864-9.85V144.84z"
          ></path>

          <!-- o -->
          <path
            class="logo_anime__text-path logo_anime__delay-1000"
            d="M699.49,99.113c0,13.684-4.503,25.417-13.505,35.2c-10.918,11.91-26.197,17.865-45.834,17.865
               s-35.023-5.955-45.94-17.865c-9.004-9.784-13.506-21.801-13.506-36.051c0-12.831,4.537-24.21,13.612-34.136
               C605.305,52.146,620.938,46.154,641.214,46.154c18.645,0,33.533,5.992,44.665,17.972C694.953,73.91,699.49,85.572,699.49,99.113z
               M663.121,99.113c0-6.41-2.242-11.84-6.723-16.292s-9.896-6.678-16.248-6.678c-7.198,0-13.055,2.707-17.571,8.121
               c-3.671,4.345-5.505,9.295-5.505,14.85c0,5.626,1.834,10.613,5.505,14.957c4.516,5.414,10.374,8.12,17.571,8.12
               c6.421,0,11.854-2.225,16.301-6.676C660.897,111.061,663.121,105.595,663.121,99.113z"
          ></path>

          <!-- r -->
          <path
            class="logo_anime__text-path logo_anime__delay-1200"
            d="M724.377,53.491h34.463v98.687h-34.463V53.491z
               M791.604,52.108c-6.27,0-11.85,1.105-16.764,3.276
               v27.848c2.586-0.747,5.479-1.135,8.704-1.135c5.02,0,9.97,1.17,14.848,3.509V52.426C795.705,52.215,793.442,52.108,791.604,52.108z"
          ></path>

          <!-- e -->
          <path
            class="logo_anime__text-path logo_anime__delay-1400"
            d="M851.853,74.117c3.667-3.541,8.463-5.312,14.387-5.312c10.717,0,17.311,5.566,19.78,16.696h-23.179v19.886
               h56.827v-4.475c0-11.648-2.589-21.875-7.763-30.682c-9.217-15.626-24.565-23.439-46.047-23.439
               c-17.44,0-30.946,4.928-40.517,14.782c-9.571,9.855-14.356,22.651-14.356,38.39c0,13.258,3.829,24.496,11.485,33.711
               c10.209,12.336,25.451,18.504,45.728,18.504c15.952,0,28.676-4.416,38.177-13.251c5.246-4.875,9.215-11.766,11.911-20.672h-33.817
               c-3.878,6.239-9.448,9.358-16.709,9.358c-14.242,0-21.362-7.407-21.362-22.226l-0.043-19.886
               C847.127,80.732,848.962,76.937,851.853,74.117z"
          ></path>
        </g>

        <!-- Text driven -->
        <g class="logo_anime__text">
          <!-- D -->
          <path
            class="logo_anime__text-path logo_anime__delay-1600"
            d="M567.667,231.18
               c-6.098-12.336-14.853-22.189-26.267-29.562c-11.628-7.586-24.247-11.379-37.858-11.379h-2.263v31.902
               c11.296,1.373,20.062,6.164,26.278,14.395c5.613,7.465,8.419,16.207,8.419,26.229s-2.807,18.801-8.419,26.336
               c-6.162,8.239-14.928,13.03-26.278,14.399v31.898h2.263c7.798,0,15.455-1.311,22.97-3.934
               c14.178-4.963,25.823-13.879,34.934-26.746c9.109-12.867,13.666-26.852,13.666-41.953
               C575.111,251.916,572.629,241.389,567.667,231.18z
               M447.817,190.238h37.461v145.158h-37.461V190.238z"
          ></path>

          <!-- r -->
          <path
            class="logo_anime__text-path logo_anime__delay-1800"
            d="M594.423,237.71h34.463v98.687h-34.463V237.71z
               M661.65,236.327c-6.27,0-11.85,1.105-16.764,3.276
               v27.848c2.586-0.747,5.479-1.135,8.704-1.135c5.02,0,9.97,1.17,14.848,3.509v-33.181
               C665.751,236.433,663.488,236.327,661.65,236.327z"
          ></path>

          <!-- i -->
          <path
            class="logo_anime__text-path logo_anime__delay-2000"
            d="M725.052,200.799c0,5.516-1.893,10.166-5.674,13.947s-8.431,5.672-13.946,5.672
               c-5.445,0-10.06-1.906-13.841-5.725s-5.673-8.449-5.673-13.895s1.891-10.059,5.673-13.84c3.782-3.783,8.396-5.676,13.841-5.676
               s10.074,1.893,13.893,5.676C723.142,190.74,725.052,195.355,725.052,200.799z
               M722.926,337.397h-34.987v-98.688h34.987V337.397z"
          ></path>

          <!-- v -->
          <path
            class="logo_anime__text-path logo_anime__delay-2200"
            d="M803.685,289.33l-23.608-50.621h-39.241l50.939,98.688h23.289l5.349-10.278l-16.698-37.853L803.685,289.33z
               M866.428,238.709h-39.028l-14.678,31.331l17.156,38.893L866.428,238.709z"
          ></path>

          <!-- e -->
          <path
            class="logo_anime__text-path logo_anime__delay-2400"
            d="M907.12,264.087c3.482-3.403,8.052-5.122,13.709-5.156c10.235-0.062,16.564,5.216,18.986,15.832
               l-22.137,0.133l0.114,18.992l54.271-0.327l-0.026-4.274c-0.067-11.124-2.598-20.876-7.591-29.257
               c-8.892-14.87-23.595-22.243-44.111-22.12c-16.656,0.1-29.526,4.885-38.61,14.35c-9.084,9.467-13.58,21.715-13.49,36.746
               c0.076,12.662,3.797,23.372,11.163,32.129c9.821,11.722,24.413,17.525,43.778,17.409c15.234-0.092,27.361-4.382,36.384-12.875
               c4.982-4.686,8.733-11.29,11.256-19.811l-32.296,0.195c-3.668,5.981-8.969,8.991-15.904,9.033
               c-13.601,0.082-20.444-6.951-20.529-21.103l-0.155-18.992C902.645,270.431,904.375,266.796,907.12,264.087z"
          ></path>

          <!-- n -->
          <path
            class="logo_anime__text-path logo_anime__delay-2600"
            d="M980.973,240.709h33.867v98.688h-33.867V240.709z
               M1073.724,247.197
               c-6.655-5.742-15.291-8.615-25.908-8.615c-6.518,0-12.168,0.982-16.976,2.913v24.687c1.063-0.168,2.157-0.268,3.299-0.268
               c5.775,0,10.109,2.088,12.999,6.266c1.972,2.83,2.959,8.6,2.959,17.307v49.91h34.988v-62.85
               C1085.085,263.504,1081.298,253.721,1073.724,247.197z"
          ></path>
        </g>
      </svg>

      <!-- ここでPC版かモバイル版の <h1> を挿入 -->
      ${messageHTML}
    </div>
  `;

    // #main_visual の要素を取得
    const mainVisual = document.getElementById('main_visual');

    // #main_visual 内に要素を追加
    if (mainVisual) {
        mainVisual.appendChild(newElement);
    } else {
        console.error('#main_visual が見つかりませんでした。');
    }

    // アコーディオン機能の実装（元のコードをそのまま使用）
    const accordionHeaders = document.querySelectorAll('.swell-accordion__header');
    accordionHeaders.forEach(header => {
        header.addEventListener('click', function () {
            this.classList.toggle('is-open');
            const content = this.nextElementSibling;

            if (content) {
                if (content.style.display === 'block') {
                    content.style.display = 'none';
                } else {
                    content.style.display = 'block';
                }
            }
        });
    });
});


document.addEventListener('DOMContentLoaded', function () {
    const target = document.querySelector('.custom-message');
    const observer = new IntersectionObserver(
        (entries) => {
            entries.forEach((entry) => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('custom-message--visible');
                } else {
                    entry.target.classList.remove('custom-message--visible');
                }
            });
        },
        { threshold: 0.1 }
    );

    if (target) {
        observer.observe(target);
    }
});

// business-section.js
document.addEventListener('DOMContentLoaded', function () {
    const viewMoreButtons = document.querySelectorAll('.view-more');

    viewMoreButtons.forEach(button => {
        button.addEventListener('click', function () {
            const content = this.closest('.business-content');
            const details = content.querySelector('.business-details');

            this.classList.toggle('active');
            details.classList.toggle('expanded');
        });
    });
});

document.addEventListener('DOMContentLoaded', () => {
    const viewMoreBtns = document.querySelectorAll('.biz__view-more');
    const closeBtns = document.querySelectorAll('.biz__close');

    viewMoreBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const cardId = btn.getAttribute('data-card');
            const details = document.getElementById(`details-${cardId}`);
            details.classList.toggle('active');
        });
    });

    closeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const details = btn.closest('.biz__details');
            details.classList.remove('active');
        });
    });
});
document.addEventListener("DOMContentLoaded", () => {
    const targets = document.querySelectorAll(".biz__content , .biz__content_reverse , .custom-message__image--mobile , .custom-message__title"); // 複数要素を取得

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("inview"); // ビューポート内に入ったらクラスを追加
            } else {
                entry.target.classList.remove("inview"); // 必要なら外す（オプション）
            }
        });
    });

    targets.forEach(target => observer.observe(target)); // すべての要素を監視
});

document.addEventListener("DOMContentLoaded", function () {
    if (window.innerWidth <= 1024) { // モバイル・タブレットのみ
        const viewMoreElements = document.querySelectorAll(".biz__view-more");
        const detailSections = document.querySelectorAll(".biz__features");
        const arrowElements = document.querySelectorAll(".biz__arrow"); // .biz__arrow の取得

        // .biz__view-more のスタイル適用と移動処理
        viewMoreElements.forEach((viewMore, index) => {
            const detailSection = detailSections[index];
            if (viewMore && detailSection) {
                detailSection.appendChild(viewMore);
                viewMore.style.background = "linear-gradient(to right, #021B79, #0575E6)"; // グラデーション適用
                viewMore.style.color = "#FFFFFF"; // 文字色を白に
                viewMore.style.transition = "background 0.3s ease-in-out, opacity 0.3s ease";
            }
        });

        // .biz__arrow にアニメーションを適用
        arrowElements.forEach(arrow => {
            arrow.style.animation = "fadeInUp 0.5s ease-in-out forwards"; // アニメーション適用
        });
    }
});
document.addEventListener("DOMContentLoaded", function () {
    const arrowElements = document.querySelectorAll(".biz__arrow");

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("fadeInUp"); // ビューポートに入ったらクラス追加
                observer.unobserve(entry.target); // 一度アニメーションしたら監視を解除
            }
        });
    });

    arrowElements.forEach(arrow => observer.observe(arrow));
});

