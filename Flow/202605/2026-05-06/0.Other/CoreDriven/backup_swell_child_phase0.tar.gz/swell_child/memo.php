<!-- 
 背景ぐらーでしょん
background: linear-gradient(134deg, rgb(162 245 255) 0%, rgb(0 61 171) 100%)

色変わる時
background-color: #d9fdff;

message
background: linear-gradient(135deg, #f2fafc 0%, #ddfdff 49%, #b5fbff 100%);

background: linear-gradient(135deg, #f9f9f9 0%,#a8e4ff 49%,#4ac8ff 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */FÏ



.logo-path {
  fill: none;
  stroke: url(#logoGradient);
  stroke-width: 1;
  stroke-dasharray: 1000;
  stroke-dashoffset: 1000;
  animation: drawPath 2s ease-out forwards;
}

@keyframes drawPath {
  to {
    stroke-dashoffset: 0;
  }
}


<div class="stackblitz-logo">
  <svg class="w-full max-w-4xl" viewBox="0 0 860.847 116.228">
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="#60A5FA" />
        <stop offset="100%" stop-color="#34D399" />
      </linearGradient>
    </defs>
    <!-- 各パスのコード -->
<path class="logo-path" d="M81.41,110.221c-8.99,3.566-17.309,5.348-24.955,5.348..." style="animation-delay: 0s"></path>
<!-- 残りのパスも同様に追加 -->
</svg>
</div>

<!-- 
document.addEventListener('DOMContentLoaded', function () {
// クラス名に合わせて変更
const baseImage = document.querySelector('.custom__base-image');
const svgPath = document.querySelector('.custom__svg-path');
const colorImage = document.querySelector('.custom__color-image');
const resetButton = document.getElementById('custom__reset-animation');

function startAnimation() {
// 要素が正常に取得できているか確認（null でないかどうか）
if (!baseImage || !svgPath || !colorImage) {
console.error('要素が見つかりません。クラス名をご確認ください。');
return;
}

baseImage.style.opacity = '0';
svgPath.style.animationPlayState = 'paused';
colorImage.style.opacity = '0';

setTimeout(() => {
baseImage.style.opacity = '1';
setTimeout(() => {
// svgPath のアニメーション再生
svgPath.style.animationPlayState = 'running';
svgPath.addEventListener('animationend', () => {
colorImage.style.opacity = '1';
}, { once: true });
}, 1000);
}, 100);
}

startAnimation();

if (resetButton) {
resetButton.addEventListener('click', startAnimation);
} else {
console.error('リセットボタンが見つかりません。ID 名をご確認ください。');
}
}); -->
<!-- 
.mycustom__animated-mask-container {
max-width: 64rem;
margin: 0 auto;
}

/* 画像を配置するコンテナ */
.mycustom__image-container {
position: relative;
aspect-ratio: 4 / 3; /* 必要に応じて aspect-ratio を設定 */
overflow: hidden;
border-radius: 0.75rem;
}

/* モノクロ画像 */
.mycustom__base-image {
width: 100%;
height: 100%;
object-fit: cover;
opacity: 0; /* 最初は非表示 */
position: relative;
z-index: 1;
transition: opacity 1s ease;
}

/* SVGマスク */
.mycustom__svg-mask-container {
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
z-index: 2;
}

/* SVG自体のスタイル */
.mycustom__animated-svg {
width: 100%;
height: 100%;
}

/* SVGパスの描画アニメーション（stroke-dashoffset で制御） */
.mycustom__path-animation {
/* stroke-dasharray をパスの長さより大きめに設定 */
stroke-dasharray: 2000;
stroke-dashoffset: 2000;
transition: stroke-dashoffset 2s ease-in-out;
}

/* カラー画像 */
.mycustom__color-image {
opacity: 0; /* 最初は非表示 */
transition: opacity 1s ease;
position: absolute;
top: 0;
left: 0;
z-index: 2;
}

/* アクティブ時に表示するためのクラス（JS で付与） */
.mycustom__base-image--active {
opacity: 1;
}

.mycustom__path-animation--active {
stroke-dashoffset: 0;
}

.mycustom__color-image--active {
opacity: 1;
}

/* リセットボタン */
.mycustom__reset-button {
display: block;
margin: 1rem auto;
padding: 0.5rem 1rem;
background-color: #1a202c;
color: white;
border: none;
border-radius: 0.375rem;
cursor: pointer;
transition: background-color 0.3s ease;
}

.mycustom__reset-button:hover {
background-color: #2d3748;
} -->

<!-- 例: テンプレート内や固定ページのHTMLエリアなどに配置 -->
<!-- <div class="mycustom__animated-mask-container">
    <div class="mycustom__image-container">
        <!-- モノクロ画像 -->
<img
  src="https://example.com/path/to/monochrome-image.png"
  alt="夜景（モノクロ）"
  class="mycustom__base-image" />

<!-- SVGマスク -->
<div class="mycustom__svg-mask-container">
  <svg
    viewBox="0 0 1649.4 1336"
    preserveAspectRatio="xMidYMid slice"
    class="mycustom__animated-svg">
    <defs>
      <clipPath id="mycustom__svg-mask">
        <path
          d="M1113.3,853.1l534.9-0.1l-486.3,482.5l-531.1-3.3l-0.2-0.2L1113.3,853.1z 
                 M519.8,707.8l-508.3,0.1l565.7,570.3l272.1-270L519.8,707.8L519.8,707.8z 
                 M1630,466.1L1165.4,0.5L634.3,0.6L633,1.9l463.3,464.3L1630,466.1L1630,466.1z 
                 M850.9,327.6l-271.5-272L1.2,635.7l512-0.1L850.9,327.6L850.9,327.6z"
          class="mycustom__svg-path" />
      </clipPath>
    </defs>

    <!-- SVGパスの描画アニメーション用 path -->
    <path
      d="M1113.3,853.1l534.9-0.1l-486.3,482.5l-531.1-3.3l-0.2-0.2L1113.3,853.1z 
             M519.8,707.8l-508.3,0.1l565.7,570.3l272.1-270L519.8,707.8L519.8,707.8z 
             M1630,466.1L1165.4,0.5L634.3,0.6L633,1.9l463.3,464.3L1630,466.1L1630,466.1z 
             M850.9,327.6l-271.5-272L1.2,635.7l512-0.1L850.9,327.6L850.9,327.6z"
      class="mycustom__path-animation"
      fill="none"
      stroke="black"
      stroke-width="2" />

    <!-- カラー画像 -->
    <image
      href="https://example.com/path/to/color-image.png"
      width="100%"
      height="100%"
      clip-path="url(#mycustom__svg-mask)"
      class="mycustom__color-image"
      preserveAspectRatio="xMidYMid slice" />
  </svg>
</div>
</div>

<!-- リセットボタン -->
<button id="mycustom__reset-animation" class="mycustom__reset-button">
  アニメーションをリセット
</button>
</div> -->