<?php
if (! defined('ABSPATH')) exit;
get_header();
if (is_front_page()) :
	SWELL_Theme::get_parts('tmp/front');
else :
	while (have_posts()) :
		the_post();
		$the_id = get_the_ID();

		// 固定ページではサイズ指定を無視して「大」を表示
		$show_pr_notation = SWELL_Theme::get_pr_notation_size($the_id, 'show_pr_notation_page');
?>
<main id="main_content" class="l-mainContent l-article">
    <div class="l-mainContent__inner" data-clarity-region="article">
        <?php SWELL_Theme::get_parts('parts/page_head'); ?>
        <?php if ($show_pr_notation) : ?>
        <?php SWELL_Theme::pluggable_parts('pr_notation'); ?>
        <?php endif; ?>
        <div class="<?= esc_attr(apply_filters('swell_post_content_class', 'post_content')) ?>">
            <?php the_content(); ?>
        </div>

				<?php if(is_page('company')): ?>
				
				<?php
					$args = array(
							'post_type' => 'post',
							'posts_per_page' => 9,
					'tag' => 'media'
					);
					$query = new WP_Query($args);
					?>
					<?php if ($query->have_posts()) : ?>
					<div class="news  u-mt-80 u-mb-80">
							<h2 class="c-pageTitle" data-style="b_bottom">
									<span class="c-pageTitle__inner">メディア</span>
							</h2>
							<div class="p-homeContent l-parent u-mt-40">
									<div class="c-tabBody p-postListTabBody">
											<div class="c-tabBody__item" aria-hidden="false">
													<ul class="p-postList -type-card -pc-col3 -sp-col1">
															<?php while ($query->have_posts()) : $query->the_post(); ?>
															<li class="p-postList__item">
																	<a href="<?php echo get_permalink(); ?>" class="p-postList__link">
																			<div class="p-postList__thumb c-postThumb noimg_">
																					<?php if (has_post_thumbnail()) : ?>
																							<?php echo get_the_post_thumbnail($post->ID, 'full'); ?>
																					<?php else : ?>
																							<img src="http://xs883463.xsrv.jp/coredriven-test-serve/wp-content/uploads/2025/01/noimage.png" alt="" class="no-img">
																					<?php endif; ?>
																			</div>
																			<div class="p-postList__body">
																					<h3 class="p-postList__title"><?php the_title(); ?></h3>
																					<div class="p-postList__meta">
																							<div class="p-postList__times c-postTimes u-thin">
																									<?php the_tags(); ?>
																							</div>
																					</div>
																			</div>
																	</a>
															</li>
															<?php endwhile; ?>
													</ul>
											</div>
									</div>
							</div>
					</div>
					<?php endif; ?>

					<?php endif; ?>
    </div>
</main>
<?php
	endwhile; // End loop
endif;
get_footer();