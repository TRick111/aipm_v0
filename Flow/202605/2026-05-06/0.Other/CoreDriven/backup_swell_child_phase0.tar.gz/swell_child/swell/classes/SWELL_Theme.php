<?php

class SWELL_Theme
{
    /**
     * ウィジェットを出力するメソッド
     *
     * @param string $widget_area ウィジェットエリアの識別子
     * @param array  $args        出力時のオプション
     */
    public static function output_widgets($widget_area, $args = [])
    {
        if (is_active_sidebar($widget_area)) {
            echo '<div class="' . esc_attr($args['before']) . '">';
            dynamic_sidebar($widget_area);
            echo esc_html($args['after']);
        }
    }

    /**
     * パーツを取得するメソッド
     *
     * @param string $part_name パーツの名前
     */
    public static function get_parts($part_name)
    {
        get_template_part($part_name);
    }

    /**
     * コンテンツウィジェットを出力するメソッド
     *
     * @param string $widget_name ウィジェット名
     * @param array  $args        出力時のオプション
     */
    public static function output_content_widget($widget_name, $args = [])
    {
        if (is_active_sidebar($widget_name)) {
            echo '<div class="' . esc_attr($args['before']) . '">';
            dynamic_sidebar($widget_name);
            echo esc_html($args['after']);
        }
    }

    /**
     * コメント表示フラグを確認するメソッド
     *
     * @return bool コメントを表示するかどうか
     */
    public static function is_show_comments()
    {
        return comments_open();
    }
}