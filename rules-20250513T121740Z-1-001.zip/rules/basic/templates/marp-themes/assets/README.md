# Marpプレゼンテーション背景画像

このディレクトリには、Marpプレゼンテーション用の背景画像を保存します。

命名規則:
- `bg_{theme_name}.png`: theme_name用背景画像

背景画像を追加したら、プレゼンテーションテンプレート内の以下の記述で使用できます:
```markdown
![bg]({{dirs.rules_basic_templates}}/marp-themes/assets/bg_professional.png)
``` 
